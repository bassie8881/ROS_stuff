#!/bin/bash

echo 0 > /sys/devices/odroid_fan.14/fan_mode

echo 200 > /sys/devices/odroid_fan.14/pwm_duty


