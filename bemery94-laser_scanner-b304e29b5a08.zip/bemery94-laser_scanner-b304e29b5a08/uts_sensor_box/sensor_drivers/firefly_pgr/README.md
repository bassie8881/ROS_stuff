firefly_pgr
===========

ROS package for working with Firefly MV camera from PointGrey research
