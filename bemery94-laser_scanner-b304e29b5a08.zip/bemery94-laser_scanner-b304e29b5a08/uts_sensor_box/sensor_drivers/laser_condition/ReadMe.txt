This file contains information about using the laser scanner software
Author: lakshitha.dantanarayana@uts.edu.au 

This software subscribes to the laser scanner topic, checks on a few param conditions before publishing it on another topic.

Requires the hokuyo laser scanner drivers.